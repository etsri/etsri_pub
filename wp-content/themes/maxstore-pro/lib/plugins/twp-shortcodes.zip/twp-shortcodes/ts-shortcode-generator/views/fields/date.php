<?php
/**
 * Field view for date picker
 */

?>

<div class="tsg-date-field">
	<input class="ts-scg-value-collector" type="hidden">
	<input class="ts-scg-date-input" type="text">
</div>